import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.DateFormat;
//import java.time.*;
import java.util.*;
import javax.swing.*;

import Modules.*;

public class Client extends Thread implements ActionListener {

	static User clientObject = new User();
	static int UserID;
	boolean sendingdone = false, receivingdone = false;
	Socket socketToServer;
	ObjectOutputStream myOutputStream;
	ObjectInputStream myInputStream;
	JFrame f;
	TextField txtMsg;
	TextArea ta;
	TextField txtFName;
	TextField txtLName;
	List list;
	int prevX;
	int prevY;
	EmptyPanel ep;
	// static ArrayList<Line> lineList;

	public Client() {

		initialize();
		// initConnection();
		f.setVisible(true);
	}

	private void initialize() {
		clientObject.lineList = new ArrayList<Line>();
		f = new JFrame();
		f.setSize(new Dimension(800, 600));
		f.setBounds(100, 100, 873, 437);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setTitle("Chat Application");
		Panel panel_2 = new Panel();
		panel_2.setSize(new Dimension(800, 500));
		f.getContentPane().add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));

		ta = new TextArea();
		// textArea.setColumns(2);
		panel_2.add(ta);
		ta.setEditable(false);

		list = new List();
		panel_2.add(list, BorderLayout.EAST);

		ep = new EmptyPanel() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				sendToServer();
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				prevX = arg0.getX();
				prevY = arg0.getY();
			}

			@Override
			public void mouseDragged(MouseEvent arg0) {
				clientObject.lineList.add(new Line(prevX, prevY, arg0.getX(), arg0.getY()));
				prevX = arg0.getX();
				prevY = arg0.getY();
				repaint();
			}

			@Override
			public void paint(Graphics g) {
				super.paint(g);
				g.setColor(Color.BLACK);
				for (Line line : clientObject.lineList) {
					g.drawLine(line.getFromX(), line.getFromY(), line.getToX(), line.getToY());
				}
			}

		};
		ep.setEnabled(false);
		panel_2.add(ep, BorderLayout.WEST);

		Button clearWhiteboard = new Button("Clear Whiteboard");
		clearWhiteboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clientObject.lineList.clear();
				ep.repaint();
				sendToServer();
			}
		});
		clearWhiteboard.setEnabled(false);
		Panel panel = new Panel();
		panel.setPreferredSize(new Dimension(10, 50));
		f.getContentPane().add(panel, BorderLayout.NORTH);

		Label label = new Label("First Name");
		label.setPreferredSize(new Dimension(80, 50));
		panel.add(label);

		TextField txtFName = new TextField();
		txtFName.setPreferredSize(new Dimension(250, 50));
		txtFName.setColumns(25);
		panel.add(txtFName);

		Label label_1 = new Label("Last Name");
		label_1.setPreferredSize(new Dimension(80, 50));
		panel.add(label_1);

		TextField txtLName = new TextField();
		txtLName.setPreferredSize(new Dimension(250, 50));
		txtLName.setColumns(25);
		panel.add(txtLName);

		Button btnConnect = new Button("Connect");

		btnConnect.setPreferredSize(new Dimension(100, 25));

		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btnConnect.setEnabled(false);
				if (btnConnect.getLabel() == "Connect" && txtFName.getText() != null && !txtFName.getText().isEmpty()
						&& txtLName.getText() != null && !txtLName.getText().isEmpty()) {
					// TODO : Initialize
					initConnection(txtFName.getText(), txtLName.getText());
					txtMsg.setEnabled(true);
					txtFName.setEnabled(false);
					txtLName.setEnabled(false);
					clearWhiteboard.setEnabled(true);
					ep.setEnabled(true);
					// btnConnect.setEnabled(false);
					btnConnect.setLabel("Disconnect");
					// btnConnect.setSize(120, 25);
					txtMsg.requestFocus();
				} else if (btnConnect.getLabel() == "Disconnect") {
					txtMsg.setEnabled(false);
					txtFName.setEnabled(true);
					txtLName.setEnabled(true);
					ep.setEnabled(false);
					clearWhiteboard.setEnabled(false);
					try {
						User u = new User();
						u.IsDisconnect = true;
						myOutputStream.reset();
						myOutputStream.writeObject(u);
						ta.setText("");
						clientObject.lineList.clear();
						list.removeAll();
						ep.repaint();
						System.exit(0);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println("Disconnect");
						e.printStackTrace();
					}
					btnConnect.setLabel("Connect");

				}
				btnConnect.setEnabled(true);
			}
		});

		panel.add(btnConnect);

		Panel panel_1 = new Panel();
		f.getContentPane().add(panel_1, BorderLayout.SOUTH);

		panel_1.add(clearWhiteboard);
		Label label_2 = new Label("Message");
		panel_1.add(label_2);

		txtMsg = new TextField();
		txtMsg.setEnabled(false);
		txtMsg.setColumns(90);
		txtMsg.addActionListener(this);
		panel_1.add(txtMsg);
	}

	private void initConnection(String FName, String LName) {
		try {

			//socketToServer = new Socket("afsaccess3.njit.edu", 9562);
			socketToServer = new Socket("localhost", 9562);

			myOutputStream = new ObjectOutputStream(socketToServer.getOutputStream());

			myInputStream = new ObjectInputStream(socketToServer.getInputStream());

			clientObject.IsNewUser = true;
			clientObject.setFirstName(FName);
			clientObject.setLastName(LName);
			if (clientObject.IsNewUser) {
				myOutputStream.reset();
				myOutputStream.writeObject(clientObject);

				clientObject = (User) myInputStream.readObject();
				ep.repaint();
				UserID = clientObject.getUserID();
				File userFile = null;
				new File("./UserData/" + UserID).mkdirs();
				userFile = new File("./UserData/" + UserID + "/" + "UserData.txt");
				if (!userFile.exists()) {
					userFile.createNewFile();
				}

				ArrayList<String> ClientHistory = _LoadTail(userFile);

				// oFile.r;
				if (!ClientHistory.isEmpty()) {
					String LastLine = ClientHistory.get(ClientHistory.size() - 1);

					clientObject.LastRequestAt = _getDateFormat().parse(LastLine.substring(0, LastLine.indexOf('#')));
					// Date.parse(LastLine.substring(0, LastLine.indexOf('#')));
					for (String cLine : ClientHistory) {
						ta.append(cLine.substring(cLine.indexOf('#') + 1) + "\n");
					}
				} else {
					clientObject.LastRequestAt = new Date(1000L);
					// LocalDateTime.of(1970, 01, 01, 00, 00);// ."1970-01-01
					// 00:00:01");
				}

				clientObject.IsNewUser = false;
				clientObject.IsHistoryRequest = true;
				myOutputStream.reset();
				myOutputStream.writeObject(clientObject);

				ArrayList<User> history = (ArrayList<User>) myInputStream.readObject();
				BufferedWriter fwriter = new BufferedWriter(new FileWriter(userFile, true));// true
																							// for
																							// Append
				if (!history.isEmpty()) {
					try {
						for (User user : history) {

							fwriter.append(_getDateFormat().format(user.getMessagedAt()) + "#" + user.getName() + " : "
									+ user.getMessage());
							fwriter.newLine();
							ta.append(user.getName() + " : " + user.getMessage() + "\n");
						}
					} catch (Exception e) {
						System.out.println("hmm");
						e.printStackTrace();
					} finally {
						if (fwriter != null) {
							fwriter.close();
						}
					}
				}
			}
			clientObject.IsHistoryRequest = false;
			clientObject.IsUserList = true;
			myOutputStream.reset();
			myOutputStream.writeObject(clientObject);

			/*
			 * User readObj = (User) myInputStream.readObject(); String[]
			 * ActiveUserList = readObj.getMessage().split(",");
			 * list.removeAll(); for (String item : ActiveUserList) {
			 * list.add(item); } list.repaint();
			 */
			clientObject.IsUserList = false;

			start();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private static DateFormat _getDateFormat() {
		return DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT);
	}

	private static ArrayList<String> _LoadTail(File file) {
		ArrayList<String> lastLine = new ArrayList<String>();
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			for (String line; (line = br.readLine()) != null;) {
				lastLine.add(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
		return lastLine;
	}

	public void actionPerformed(ActionEvent ae) {

		sendToServer();

	}

	private void sendToServer() {
		clientObject.setMessage(txtMsg.getText());
		txtMsg.setText("");
		try {
			myOutputStream.reset();
			myOutputStream.writeObject(clientObject);
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		}
	}

	public void run() {
		clientObject.IsHistoryRequest = false;

		System.out.println("Listening for messages from server . . . ");
		try {
			while (!receivingdone) {
				User readObj = new User();
				readObj = (User) myInputStream.readObject();
				if (readObj.IsUserList) {
					String[] ActiveUserList = readObj.getMessage().split(",");
					list.removeAll();
					for (String item : ActiveUserList) {
						list.add(item);
					}
					list.repaint();
					// clientObject.lineList = readObj.getLineList();
					// ep.repaint();
				} else {
					if (readObj.getMessage() != null && !readObj.getMessage().isEmpty()) {
						ta.append(readObj.getName() + " : " + readObj.getMessage() + "\n");
						_writeToFile(readObj);
					}

					clientObject.lineList = readObj.getLineList();
					ep.repaint();
				}

			}
		} catch (IOException ioe) {
			System.out.println("IOE: " + ioe.getMessage());
		} catch (ClassNotFoundException cnf) {
			System.out.println(cnf.getMessage());
		}
	}

	private synchronized void _writeToFile(User clientObject2) throws IOException {
		File userFile = null;
		new File("./UserData/" + UserID).mkdirs();
		userFile = new File("./UserData/" + UserID + "/" + "UserData.txt");
		if (!userFile.exists()) {
			userFile.createNewFile();
		}

		BufferedWriter fwriter = new BufferedWriter(new FileWriter(userFile, true)); // True
																						// to
																						// append

		try {
			fwriter.append(_getDateFormat().format(clientObject2.getMessagedAt()) + "#" + clientObject2.getName() + " "
					+ clientObject2.getMessage());
			fwriter.newLine();
		} catch (Exception e) {
			System.out.println("FileWrite");
			e.printStackTrace();
		} finally {
			if (fwriter != null) {
				fwriter.close();
			}
		}

	}

	public static void main(String[] arg) {
		Client c = new Client();
	}

}
