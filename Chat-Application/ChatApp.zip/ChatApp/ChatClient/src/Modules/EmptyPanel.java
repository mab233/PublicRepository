package Modules;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;

public abstract class EmptyPanel extends Panel implements MouseMotionListener, MouseListener {

	
	public EmptyPanel(){
		setBackground(Color.LIGHT_GRAY);
		addMouseListener(this);
		addMouseMotionListener(this);
		this.setPreferredSize(new Dimension(350, 300));
		this.setMinimumSize(new Dimension(350, 300));
		
	}
	
	@Override
	public void paint(Graphics g){
		
		//System.out.println("inner");
		super.paint(g);
		
	}
	
	
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
}
