import java.net.*;
import java.util.*;

public class ChatServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<ChatServerHelper> AllHandlers = new ArrayList<ChatServerHelper>();
		
	      try 
	      {  ServerSocket s = new ServerSocket(9562);
	         
	         for (;;)
	         {  
	        	 //System.out.println("New Connection...");
	        	 Socket incoming = s.accept( );
	        	 System.out.println(incoming.getRemoteSocketAddress());
	            new ChatServerHelper(incoming, AllHandlers).start();

	         }   
	      }
	      catch (Exception e) 
	      
	      { 
	    	  e.printStackTrace();
	    	  System.out.println(e);
	      } 
	}

}
