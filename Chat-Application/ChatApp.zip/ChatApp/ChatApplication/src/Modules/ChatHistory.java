package Modules;

import java.util.ArrayList;

public class ChatHistory {
	ArrayList<User> List = new ArrayList<User>();
}
