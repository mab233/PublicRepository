package Modules;

import java.util.*;

public class User extends ChatMessage {
	private int UserID;
	private String FirstName;
	private String LastName;
	private String UserName;
	private boolean HasConnected;
	public boolean IsUserList;
	public String Password;

	public ArrayList<Line> lineList = new ArrayList<Line>();

	public boolean IsNewUser;

	public boolean IsHistoryRequest;
	private Date MessagedAt;
	public Date LastRequestAt;
	public boolean IsDisconnect = false;

	public User() {
		this.FirstName = "";
		this.LastName = "";
	};

	public User(String name) {
		this.setName(name);
	}

	public User(String firstName, String lastName) {
		this.FirstName = firstName;
		this.LastName = lastName;
		this.setName();
	}

	public User(User newObj) {
		this.FirstName = newObj.FirstName;
		this.UserID = newObj.UserID;
		this.LastName = newObj.LastName;
		this.HasConnected = newObj.HasConnected;
		this.LastRequestAt = newObj.LastRequestAt;
		this.IsHistoryRequest = newObj.IsHistoryRequest;
		this.IsNewUser = newObj.IsNewUser;
		this.setMessage(newObj.getMessage());
		this.MessagedAt = newObj.MessagedAt;
		this.UserName = newObj.UserName;
		this.lineList.clear();
		this.lineList.addAll(newObj.getLineList());
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return FirstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return LastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		LastName = lastName;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return UserName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		UserName = userName;
	}

	public void setName() {
		this.name = this.FirstName + " " + this.LastName;
	}

	@Override // To indicate following method is overridden method and ask
				// Compiler to Make sure of it
	public void setName(String Name) {

		this.FirstName = Name.split(" ", 2)[0];
		this.LastName = Name.split(" ", 2)[1];
		this.name = Name;
	}

	@Override // To indicate following method is overridden method and ask
				// Compiler to Make sure of it
	public String getName() {
		if (name == null || name.isEmpty()) {
			return this.FirstName + " " + this.LastName;
		}
		return name;
	}

	/**
	 * @return the hasConnected
	 */
	public boolean isHasConnected() {
		return HasConnected;
	}

	/**
	 * @param hasConnected
	 *            the hasConnected to set
	 */
	public void setHasConnected(boolean hasConnected) {
		HasConnected = hasConnected;
	}

	/**
	 * @return the userID
	 */
	public int getUserID() {
		return UserID;
	}

	/**
	 * @param userID
	 *            the userID to set
	 */
	public void setUserID(int userID) {
		UserID = userID;
	}

	/**
	 * @return the messagedAt
	 */
	public Date getMessagedAt() {
		return MessagedAt;
	}

	/**
	 * @param messagedAt
	 *            the messagedAt to set
	 */
	public void setMessagedAt(Date messagedAt) {
		MessagedAt = messagedAt;
	}

	/**
	 * @return the lineList
	 */
	public ArrayList<Line> getLineList() {
		return lineList;
	}

	/**
	 * @param lineList
	 *            the lineList to set
	 */
	public void setLineList(ArrayList<Line> lineList) {
		this.lineList.clear();
		this.lineList.addAll(lineList);
	}
}
