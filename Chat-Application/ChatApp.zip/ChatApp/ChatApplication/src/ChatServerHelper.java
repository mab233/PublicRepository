import java.io.*;
import java.util.*;
import java.net.*;
//import java.time.LocalDateTime;

import Modules.*;
import chat.Db.*;

public class ChatServerHelper extends Thread {
	public ChatServerHelper(Socket i, ArrayList<ChatServerHelper> h) {
		incoming = i;
		handlers = h;
		handlers.add(this);
		try {
			in = new ObjectInputStream(incoming.getInputStream());
			out = new ObjectOutputStream(incoming.getOutputStream());
		} catch (IOException ioe) {
			System.out.println("Could not create streams.");
		}
	}

	public synchronized void broadcast() {
		if (!currentUserObj.IsNewUser) {
			// TODO: Database Call to add chat message
			if (currentUserObj.getMessage() != null && !currentUserObj.getMessage().isEmpty())
				new DatabaseUtility().InsertChatMessage(currentUserObj.getUserID(), currentUserObj.getMessage(),
						currentUserObj.getMessagedAt());
			ArrayList<ChatServerHelper> left = new ArrayList<ChatServerHelper>();
			for (ChatServerHelper handler : handlers) {
				User cm = new User(currentUserObj);
				cm.lineList = lines;
				// cm.setMessage(currentUserObj.getMessage());
				try {
					handler.out.writeObject(cm);
					System.out.println("Writing to handler outputstream: " + cm.getMessage());
				} catch (IOException ioe) {
					// one of the other handlers hung up
					left.add(handler); // remove that handler from the arraylist
					handler.currentUserObj.getUserID();
				}
			}
			if (left.size() > 0) {
				handlers.removeAll(left);
				// TODO: Database Call to Change has Connected
				broadcastUsers();
			}
			System.out.println("Number of handlers: " + handlers.size());
		}
	}

	public synchronized void broadcastUsers() {
		if (!currentUserObj.IsNewUser) {
			// TODO: Database Call to add chat message
			String activeUsers = "";
			for (ChatServerHelper h : handlers) {
				activeUsers += "," + h.currentUserObj.getName();
			}
			activeUsers = activeUsers.replaceFirst(",", "");
			User cm = new User(currentUserObj);
			cm.IsUserList = true;
			cm.setMessage(activeUsers);
			for (ChatServerHelper handler : handlers) {

				try {
					handler.out.writeObject(cm);
					System.out.println("Writing to handler outputstream (Active Users): ");
				} catch (IOException ioe) {
					System.out.println("Active User");
				}
			}
			/*
			 * if (currentUserObj.getMessage().equals("bye")) { // my client
			 * wants // to // leave done = true; handlers.remove(this);
			 * System.out.println("Removed handler. Number of handlers: " +
			 * handlers.size()); }
			 */
			System.out.println("Number of handlers: " + handlers.size());
		}
	}

	public void run() {
		try {
			while (!done) {

				currentUserObj = (User) in.readObject();

				currentUserObj.setMessagedAt(new Date());
				if (!currentUserObj.IsNewUser && !currentUserObj.IsHistoryRequest && !currentUserObj.IsDisconnect
						&& !currentUserObj.IsUserList) {
					System.out.println("Message read: " + currentUserObj.getMessage());
					lines = currentUserObj.lineList;
					broadcast();
				} else if (currentUserObj.IsNewUser) {
					currentUserObj.setUserID(
							new DatabaseUtility().AddUser(currentUserObj.getFirstName(), currentUserObj.getLastName()));
					currentUserObj.lineList = lines;
					this.out.writeObject(currentUserObj);

				} else if (currentUserObj.IsHistoryRequest) {
					this.out.writeObject(new DatabaseUtility().GetChatMessages(currentUserObj.LastRequestAt));
				} else if (currentUserObj.IsDisconnect) {
					handlers.remove(this);
					System.out.println("Removed handler. Number of handlers: " + handlers.size());
					broadcastUsers();
				} else if (currentUserObj.IsUserList) {
					System.out.println("Number of handlers: " + handlers.size());
					broadcastUsers();
				}
			}
		} catch (IOException e) {

			if (e.getMessage().equals("Connection reset")) {
				System.out.println("A client terminated its connection.");
				handlers.remove(this);
				broadcastUsers();
			} else {
				System.out.println("Problem receiving: " + e.getMessage());
			}
		} catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		/*
		 * finally { handlers.remove(this); broadcastUsers(); }
		 */
	}

	User currentUserObj = null;
	private Socket incoming;

	boolean done = false;
	ArrayList<ChatServerHelper> handlers;
	static ArrayList<Line> lines = new ArrayList<Line>();
	ObjectOutputStream out;
	ObjectInputStream in;
}
