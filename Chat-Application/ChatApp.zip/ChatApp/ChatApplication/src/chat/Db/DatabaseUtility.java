package chat.Db;

import Modules.*;
import java.sql.*;
//import java.time.LocalDateTime;
import java.util.Date;
import java.util.ArrayList;

public class DatabaseUtility {
	static String dbURL = "jdbc:mysqlU://TODO_UPDATE_URL/";
	static String dbInstanceName = "mab233";
	static String dbDriver = "com.mysql.jdbc.Driver";
	static String dbUserName = "TODO_UserName";
	static String dbPassword = "TODO_Password;
	// Connection conn = null;

	private static Connection _getConnection() {
		try {
		System.out.println("DB");
			Class.forName(dbDriver).newInstance();

			conn = DriverManager.getConnection(dbURL + dbInstanceName, dbUserName, dbPassword);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Connection Failure to the database.");
		}
		return conn;
	}

	static Connection conn = _getConnection();

	public int AddUser(String FirstName, String LastName) {
		return AddUser(FirstName, LastName, true);
	}

	public int AddUser(String FirstName, String LastName, boolean HasConnected) {
		// conn = _getConnection();
		// Statement stmt;
		int result = 0;
		try {
			/*
			 * stmt = conn.createStatement(); String query =
			 * "INSERT INTO users(FirstName,LastName,HasConnected) VALUES ('" +
			 * FirstName + "','" + LastName + "'," + HasConnected + ")"; result
			 * = stmt.executeUpdate(query);
			 */
			CallableStatement callStmt = conn.prepareCall("{call InsertUser(?,?,?,?)}");
			callStmt.setString("FrstName", FirstName);
			callStmt.setString("LstName", LastName);
			callStmt.setBoolean("HasConnected", HasConnected);
			callStmt.registerOutParameter("UsrID", Types.INTEGER);

			callStmt.execute();
			result = callStmt.getInt("UsrID");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ArrayList<User> SelectUsers() {
		// conn = _getConnection();
		Statement stmt;
		int result = 0;
		ArrayList<User> UserList = new ArrayList<User>();
		User currentUser = null;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Users");
			while (rs.next()) {
				// Retrieve by column name
				currentUser = new User();
				currentUser.setUserID(rs.getInt("UserID"));
				currentUser.setHasConnected(rs.getBoolean("HasConnected"));
				currentUser.setFirstName(rs.getString("FirstName"));
				currentUser.setLastName(rs.getString("LastName"));
				UserList.add(currentUser);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return UserList;
	}

	public int InsertChatMessage(int UserID, String Message, Date timeStamp) {
		// conn = _getConnection();
		Statement stmt;
		int result = 0;
		try {
			CallableStatement callStmt = conn.prepareCall("{call InsertChatMessage(?,?,?)}");
			callStmt.setInt("UsrID", UserID);
			callStmt.setString("Msg", Message);
			callStmt.setObject("MsgAt", timeStamp, Types.TIMESTAMP);
			callStmt.execute();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ArrayList<User> GetChatMessages(Date MinTime) {
		// conn = _getConnection();
		Statement stmt;
		ArrayList<User> ChatList = new ArrayList<User>();
		try {

			CallableStatement callStmt = conn.prepareCall("{call GetChatMessage(?)}");
			callStmt.setObject("MinTime", MinTime, Types.TIMESTAMP);

			callStmt.execute();
			ResultSet rs = callStmt.getResultSet();
			User currentUser = null;

			while (rs.next()) {
				// Retrieve by column name
				currentUser = new User();
				currentUser.setName(rs.getString("Name"));
				currentUser.setMessage(rs.getString("Message"));
				currentUser.setMessagedAt(rs.getTimestamp("MessageAt"));
				ChatList.add(currentUser);
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("History");
		}
		return ChatList;
	}

	public int UserDisconnect(String UserIDList) {
		// conn = _getConnection();
		Statement stmt;
		int result = 0;
		try {
			stmt = conn.createStatement();
			String query = "UPDATE Users SET HasConnected = 0 WHERE UserID IN(" + UserIDList + ")";
			result = stmt.executeUpdate(query);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
